<?php
require_once ("../database.php");
if(isset($_POST['user'])){
   $q='SELECT * FROM users WHERE username="'.$_POST['user'].'" ';
   $r= mysqli_query($con, $q);
   if($r){
       if(mysqli_num_rows($r) >0){
           echo '<p style="color:red" >Username already exist</p>';
           
       } else {
          echo '<p style="color:green">Username available</p>'; 
       }
   } else {
       echo $q;
   }
}


?>