
<?php
// mysql connection
$host = "localhost";
$user = "root";
$pass = "";
$db = "nistbook";
$con = mysqli_connect($host, $user, $pass, $db) or die("Error " . mysqli_error($con));

if (isset($_POST["username"]))
{
    $username = mysqli_real_escape_string($con, $_POST["username"]);
    $sql = "select  username from users where username='$username'";
    $result = mysqli_query($con, $sql);
    echo mysqli_num_rows($result);
}



?>