<?php
session_start();
include "database.php";
if(isset($_POST['login'])){
    $email= mysqli_real_escape_string($con, $_POST['email']);
      $username= mysqli_real_escape_string($con, $_POST['username']);
    $select_user="SELECT * FROM users WHERE Email='$email' and username='$username'  ";
         

    $check= mysqli_query($con, $select_user);
    $check_user= mysqli_num_rows($check);
    if($check_user==1){
        $_SESSION['username']=$username;
      
        echo "<script>window.open('home.php','_self')</script>";
    }
 else {
        echo "<script>alert('email or password incorrect, try again')</script>";  
    }
}
?>
<html>
    <head>
        <title>
        </title>
        
    </head>
    <body>
        
         <form method="post" action="" id="form1">
                        <strong>Email:</strong>
                        <input type="email" name="email" placeholder="email" required/>
                         <strong>Password:</strong>
                         <input type="username" name="username" placeholder="username" required/>
                         <button name="login">Login</button>
                    </form>
    </body>
</html>
