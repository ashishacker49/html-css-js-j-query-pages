<?php
require_once 'database.php';

if (isset($_POST['submit']))
{
    $uname=$_POST['username'];
   
    $email=$_POST['email'];
   
}
$sql="INSERT INTO users (username,Email)
    VALUES('".$uname."', '".$email."')";
if (mysqli_query($con, $sql)) {
  echo "YOU are successfully registered";
 header("Refresh: 3; url=login.php");
 // header("Refresh: 3; url=home.php");
}
 else {
  echo "Error: " . $sql . "<br>" . mysqli_error($con);
}
?>