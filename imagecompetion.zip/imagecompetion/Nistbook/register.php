<!DOCTYPE html>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <title>Live Check for Username Availability Using PHP & jQuery AJAX | Demo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <title>
            Registation Forms
        </title>
</head>
<body>
<div class="container" style="margin-top: 20px;">
    <div class="row">
        <div class="col-xs-4 col-xs-offset-4">
            <form action="registered.php" method="post">
                <legend>Check Username Availabilty:</legend>

                <div class="form-group">
                    <input type="text" id="username" name="username" placeholder="Enter username" class="form-control" />
                </div>
                <div id="msg" class="form-group"></div>
                <div class="form-group">
                    <input type="text" id="email" placeholder="Email ID" name="email" class="form-control" />
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" id="submit" value="submit" disabled class="btn btn-block btn-primary" />
                </div>
            </form>
        </div>
    </div>
</div>



<script type="text/javascript">
$(document).ready(function() {
$("#username").blur(function(e) {
    var uname = $(this).val();
    if (uname == "")
    {
        $("#msg").html("");
        $("#submit").attr("disabled", true);
    }
    else
    {
        $("#msg").html("checking...");
        $.ajax({
            url: "check.php",
            data: {username: uname},
            method: "POST",
            success: function(data) {
                if(data > 0) {
                    $("#msg").html('<span class="text-danger">Username is already taken!</span>');
                    $("#submit").attr("disabled", true);
                } else {
                    $("#msg").html('<span class="text-success">Username is available!</span>');
                    $("#submit").attr("disabled", false);
                    
                    
                }
            }
        });
    }
});
});

</script>

</body>
</html>