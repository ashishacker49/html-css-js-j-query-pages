<?php
$con= mysqli_connect("localhost","root","","nistbook")or die("Connection failed");



?>

